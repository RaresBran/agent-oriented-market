package sma;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

final class InteractionRecord {
    private final String initiatorId;
    private final String partnerId;
    private final List<String> sold;
    private final List<String> bought;

    private InteractionRecord(String initiatorId, String partnerId,
                              List<String> sold, List<String> bought) {
        this.initiatorId = initiatorId;
        this.partnerId = partnerId;
        this.sold = sold;
        this.bought = bought;
    }

    static InteractionRecord trade(Agent a, Agent b, Map<String, Integer> prices) {
        List<String> sold = new ArrayList<>();
        List<String> bought = new ArrayList<>();
        applyTransactions(a, b, prices, sold);
        applyTransactions(b, a, prices, bought);
        return new InteractionRecord(a.getId(), b.getId(), sold, bought);
    }

    private static void applyTransactions(Agent seller, Agent buyer,
                                          Map<String, Integer> prices,
                                          List<String> output) {
        for (Map.Entry<String, Integer> entry : seller.getSellsRemaining().entrySet()) {
            String product = entry.getKey();
            int quantity = entry.getValue();
            int want = buyer.getBuysRemaining().getOrDefault(product, 0);
            int price = prices.getOrDefault(product, 0);
            int maxAffordable = price > 0 ? buyer.getCash() / price : 0;
            int tradeQty = Math.min(Math.min(quantity, want), maxAffordable);
            if (tradeQty <= 0)
                continue;
            entry.setValue(quantity - tradeQty);
            buyer.getBuysRemaining().put(product, want - tradeQty);
            buyer.getInventory().merge(product, tradeQty, Integer::sum);
            seller.setCash(seller.getCash() + tradeQty * price);
            buyer.setCash(buyer.getCash() - tradeQty * price);
            output.add(tradeQty + " " + product);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(initiatorId)
                .append(" to ").append(partnerId).append(":");
        if (!sold.isEmpty()) {
            sb.append(" sells ").append(String.join(", ", sold));
        }
        if (!bought.isEmpty()) {
            if (!sold.isEmpty()) {
                sb.append(" and");
            }
            sb.append(" buys ").append(String.join(", ", bought));
        }
        if (sold.isEmpty() && bought.isEmpty()) {
            sb.append(" no transaction");
        }
        return sb.toString();
    }
}
