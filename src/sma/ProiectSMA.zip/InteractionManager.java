package sma;

import java.util.*;

final class InteractionManager {
    static List<InteractionRecord> performStep(List<Agent> agents, Map<String, Integer> prices, int step) {
        List<Agent> shuffled = new ArrayList<>(agents);
        Collections.shuffle(shuffled);
        List<InteractionRecord> records = new ArrayList<>();

        for (Agent initiator : shuffled) {
            if (!initiator.canInitiate(step)) {
                continue;
            }

            Optional<Agent> partner = initiator.choosePartner(shuffled);
            partner.filter(Agent::canBeContacted).ifPresent(p -> {
                initiator.markInteracted(step);
                p.markBusy();
                records.add(InteractionRecord.trade(initiator, p, prices));
            });
        }
        return records;
    }
}
